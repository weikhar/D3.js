
### vehicle_sales_data.csv

This file was derived from data compiled by Yan (Joann) Zhou at Argonne National Laboratory, U.S. Department of Energy, as provided by email on March 20, 2017.

Note: Some values are estimates, while a handful have been interpolated by me (Scott Murray), to fit the structure needed for this example project.  That is to say, I do not recommend using this derivative data for any other purposes; it is best to retrieve the original and make your own judgements about how to interpret it.

“Light Duty Electric Drive Vehicles Monthly Sales Updates”

More info:
https://www.anl.gov/energy-systems/project/light-duty-electric-drive-vehicles-monthly-sales-updates
